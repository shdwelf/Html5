Please read the Manual MAKSActiveX.pdf (in Adobe Acrobat Reader Format)

Lesen Sie bitte die Anleitung MAKSActiveXd.pdf (in Adobe Acrobat Reader Format)