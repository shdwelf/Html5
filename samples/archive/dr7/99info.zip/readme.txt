Stolen from DR7 1998
http://plaza.v-wave.com/dr7/